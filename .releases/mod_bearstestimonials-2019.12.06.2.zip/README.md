# mod_bearstestimonials
Testimonials module for Joomla 3.9
